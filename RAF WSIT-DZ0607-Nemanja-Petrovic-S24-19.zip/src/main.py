from flask import Flask, render_template,redirect, url_for, request, session
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
import hashlib
import time
import mysql.connector

mydb = mysql.connector.connect(
	host="localhost",
	user="root",
	password="",
	database="raspored"
)

app = Flask(__name__)

@app.route('/')
@app.route('/index')
def index():
	return render_template('index.html')

@app.route('/raspored')
def raspored():

	mc = mydb.cursor()
	mc.execute("SELECT * FROM raspored")
	res = mc.fetchall()

	lista_nastavnika = [r[3] for r in res]
	lista_ucionica = [r[7] for r in res]

	svi_nastavnici = []
	for predavac in lista_nastavnika:
		if predavac not in svi_nastavnici:
			svi_nastavnici.append(predavac)

	sve_ucionice = []
	for ucionica in lista_ucionica:
		if ucionica not in sve_ucionice:
			sve_ucionice.append(ucionica)

	lista_nastavnika = svi_nastavnici.sort()
	lista_ucionica = sve_ucionice.sort()
	
	pr = len(svi_nastavnici)
	uc = len(sve_ucionice)
	if pr > uc:
		broj = pr
	else:
		broj = uc

	return render_template("raspored.html", 
		raspored =res,
		broj = broj, pr = pr, uc = uc,
		nastavnici = svi_nastavnici, 
		ucionice = sve_ucionice
	)

if __name__ == '__main__':
	app.run(debug=True)

	