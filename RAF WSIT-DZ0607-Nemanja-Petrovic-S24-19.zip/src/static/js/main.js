$(document).ready(function() {
    $('#pretraga').keyup(function() {
        search_table($(this).val(), $('#tabela_raspored1 tr'));
    })
    
    function search_table(txt, tabela) {
        tabela.each(function() {
            $(this).each(function() {
                if($(this).text().toLowerCase().indexOf(txt.toLowerCase()) >= 0) 
                {
                    $(this).show().css("background", "#0f579b");
                }
                else 
                {
                    $(this).hide();
                }
            });
        });
        $("tr:visible:even").css("background", "#04325c");
    }

    $(".link").click(function(e) 
    { 
        var text = $(this).text();
        var tb = $("#tabela_raspored1");
            search_table(text, $('tr', tb));
            $("tr:visible:even", tb).css("background", "#04325c");
    });
});
